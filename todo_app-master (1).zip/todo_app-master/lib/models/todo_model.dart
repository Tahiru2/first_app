class TodoModel {
  String title;
  String description;

  TodoModel({
    required this.title,
    required this.description,
  });
}

List<TodoModel> todosList = [];
